import React from 'react';
import { NotFoundBlock } from '../components';

const NotFound: React.FC = () => <NotFoundBlock />;

export default NotFound;
